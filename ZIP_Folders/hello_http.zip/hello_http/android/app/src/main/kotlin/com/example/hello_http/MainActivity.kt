package com.example.hello_http

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
