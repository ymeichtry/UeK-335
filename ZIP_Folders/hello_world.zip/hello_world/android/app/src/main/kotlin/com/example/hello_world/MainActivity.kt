package com.example.hello_world

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
